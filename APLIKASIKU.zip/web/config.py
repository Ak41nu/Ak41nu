import os
basedir = os.path.abspath(os.path.dirname(__file__))
class Konfigurasi:
    SECRET_KEY = os.getenv('SECRET_KEY', default='136f0ec3f6b308ce118d85b28b50223087104b70fe960f7e9d3052d5b09d3d421d7a0e9d386bf16fb346362e3eb03dfcd6f7ed0b1465a8dd5eebfd4557975964')
    SQLALCHEMY_DATABASE_URI = os.getenv('SQLALCHEMY_DATABASE_URI', default='sqlite:///cmsflask.db')
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 465
    MAIL_USE_SSL = True
    MAIL_USERNAME = os.getenv('EMAIL_USERNAME')
    MAIL_PASSWORD = os.getenv('EMAIL_PASSWORD')
    UPLOADED_PATH = os.path.join(basedir, 'upload')
    CKEDITOR_SERVE_LOCAL = True
    CKEDITOR_HEIGHT = 400
    CKEDITOR_EXTRA_PLUGINS = ['youtube']
    CKEDITOR_FILE_UPLOADER = 'admin.upload'
    CKEDITOR_ENABLE_CSRF = True
    DIREKTORI = basedir
    SQLALCHEMY_TRACK_MODIFICATIONS = False