from datetime import datetime
from itsdangerous import Serializer
from flask import current_app
from flask_login import UserMixin
from hashlib import md5
from web import dbase, login

@login.user_loader
def load_user(idpengguna):
    return Pengguna.query.get(int(idpengguna))

class Judul(dbase.Model):
    id = dbase.Column(dbase.Integer, primary_key=True)
    judul = dbase.Column(dbase.String(100), nullable=False)
    deskripsi = dbase.Column(dbase.String(300), nullable=False)
    hero = dbase.Column(dbase.Text, nullable=False)
    judulsh1 = dbase.Column(dbase.Text, nullable=False)
    judulsh2 = dbase.Column(dbase.Text, nullable=False)
    judulsh3 = dbase.Column(dbase.Text, nullable=False)
    isish1 = dbase.Column(dbase.Text, nullable=False)
    isish2 = dbase.Column(dbase.Text, nullable=False)
    isish3 = dbase.Column(dbase.Text, nullable=False)
    footer1 = dbase.Column(dbase.Text, nullable=False)
    footer2 = dbase.Column(dbase.Text, nullable=False)
    header = dbase.Column(dbase.Text, nullable=False)
    @staticmethod
    def tambahjudul():
        judul = ['CMSFlask']
        for r in judul:
            judul = Judul.query.filter_by(judul=r).first()
            if judul is None:
                judul = Judul(judul='CMSFlask', deskripsi='Layanan Website Dengan NgFlask PythonesiaORG Framework CMS Python',hero='CMS Python Yang Mudah Digunakan, Dikembangkan Dalam Berbagai Model Dan Memiliki Tingkat Keamanan Yang Tinggi',
                              judulsh1='Mudah Digunakan',judulsh2='Pengembangan Dinamis',judulsh3='Keamanan Website',isish1='Framework CMS NgFlask sangat mudah digunakan karena menawarkan antarmuka yang sederhana dan intuitif. Pengguna dapat dengan cepat mengelola konten tanpa memerlukan pengetahuan teknis mendalam. Berbasis Flask, NgFlask memungkinkan integrasi fitur tambahan dengan fleksibilitas tinggi, membuatnya ideal untuk berbagai jenis proyek web',
                              isish2='Framework CMS NgFlask mudah dikembangkan karena berbasis Flask, yang ringan dan fleksibel. Pengembang dapat dengan mudah menambahkan fitur kustom, mengintegrasikan API, dan memodifikasi fungsi sesuai kebutuhan proyek. Arsitekturnya yang modular mempermudah pengembangan aplikasi web yang skalabel dan dinamis',
                              isish3='Framework CMS NgFlask memiliki keamanan tinggi dengan fitur bawaan seperti proteksi terhadap serangan CSRF dan XSS. Berbasis Flask, NgFlask mendukung enkripsi password yang aman dan otentikasi pengguna yang kuat. Pengembang juga dapat dengan mudah menambahkan lapisan keamanan tambahan sesuai kebutuhan.',
                              footer1='Framework CMS NgFlask menawarkan kemudahan penggunaan dengan antarmuka yang sederhana, memungkinkan pengguna mengelola konten tanpa kesulitan. Berbasis Flask, NgFlask mudah dikembangkan dan fleksibel, memudahkan pengembang menambah fitur dan menyesuaikan sesuai kebutuhan proyek. Dari segi keamanan, NgFlask sudah dilengkapi proteksi bawaan seperti CSRF dan XSS, serta otentikasi pengguna dan enkripsi password yang kuat, menjaga keamanan data pengguna',
                              footer2='Indonesia',header='email:dev@pythonesia.org,telp:08888888 ')
            dbase.session.add(judul)
        dbase.session.commit()

class Pengguna(dbase.Model, UserMixin):
    id = dbase.Column(dbase.Integer, primary_key=True)
    nama = dbase.Column(dbase.String(20), nullable=False)
    surel = dbase.Column(dbase.String(120), unique=True, nullable=False)
    gambar = dbase.Column(dbase.String(20), nullable=False, default='default.jpg')
    kunci = dbase.Column(dbase.String(60), nullable=False)
    biodata = dbase.Column(dbase.String(255))
    sebagai = dbase.Column(dbase.String(60), nullable=False)
    aktifasi = dbase.Column(dbase.String(5), nullable=False, default='Tidak')
    tgldaftar = dbase.Column(dbase.DateTime, nullable=False, default=datetime.utcnow)
    absensikehadiran = dbase.relationship('Absensikehadiran', back_populates='pengguna')

    def __init__(self, **kwargs):
        super(Pengguna, self).__init__(**kwargs)
    def get_reset_token(self, expires_sec=1800):
        s = Serializer(current_app.config['SECRET_KEY'], expires_sec)
        return s.dumps({'idpengguna': self.id}).decode('utf-8')
    @staticmethod
    def verify_reset_token(token):
        s = Serializer(current_app.config['SECRET_KEY'])
        try:
            idpengguna = s.loads(token)['idpengguna']
        except:
            return None
        return Pengguna.query.get(idpengguna)
    def __repr__(self):
        return "Pengguna('{self.nama}', '{self.surel}', '{self.gambar}')"

class Absensikehadiran(dbase.Model):
    id = dbase.Column(dbase.Integer, primary_key=True)
    statuskehadiran = dbase.Column(dbase.String(5), nullable=False, default='Tidak')
    tglabsen = dbase.Column(dbase.DateTime, nullable=False, default=datetime.utcnow)
    penggunaid = dbase.Column(dbase.Integer, dbase.ForeignKey('pengguna.id'))
    
    pengguna = dbase.relationship('Pengguna', back_populates='absensikehadiran')
    
    
    


