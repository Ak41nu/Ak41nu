import os
import secrets
from flask import current_app
from PIL import Image
import datetime
from flask import url_for,current_app
from flask_mail import Message
from web.database import  Judul
from web import mail

def save_picture(form_picture):
    random_hex = secrets.token_hex(8)
    _, f_ext = os.path.splitext(form_picture.filename)
    picture_fn = random_hex + f_ext
    picture_path = os.path.join(current_app.root_path, 'static/upload/img_thumbnail', picture_fn)
    output_size = (800, 800)
    i = Image.open(form_picture)
    i.thumbnail(output_size)
    i.save(picture_path)
    return picture_fn

def save_picture_profile(form_picture):
    random_hex = secrets.token_hex(8)
    _, f_ext = os.path.splitext(form_picture.filename)
    picture_fn = random_hex + f_ext
    picture_path = os.path.join(current_app.root_path, 'static/upload/profile_pics', picture_fn)
    output_size = (400, 400)
    i = Image.open(form_picture)
    i.thumbnail(output_size)
    i.save(picture_path)

    return picture_fn

def send_reset_email(user):
    token = user.get_reset_token()
    msg = Message('Password Reset Request',sender=current_app.config['MAIL_USERNAME'],recipients=[user.email])
    msg.body = f'''Untuk mereset password, Silahkan klik link ini:{url_for('admin.reset_token', token=token, _external=True)}Jika Anda tidak ingin mengganti password, abaikan pesan ini.'''
    mail.send(msg)