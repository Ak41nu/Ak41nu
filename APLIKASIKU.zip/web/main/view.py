import os
import secrets
import codecs
from flask import render_template, url_for, flash, redirect, request, send_from_directory, Blueprint, current_app,session,jsonify
from flask_mail import Message
from slugify import slugify
from web import dbase, bcrypt, mail
from web.database import Pengguna,  Judul, Absensikehadiran
from web.form import  FormUpdateAkun, FormRegistrasi, FormLogin, FormPermintaanReset, FormResetPassword, FormSebagai
from web.main.util import save_picture, save_picture_profile, send_reset_email
import requests
import re

main = Blueprint('main', __name__)

@main.route("/", methods=['GET', 'POST'])
def admin_index():
    if 'sebagai' in session:
        if session['sebagai']=='admin':
            return redirect(url_for('main.dashboard'))
        elif session['sebagai']=='penjual':
            return redirect(url_for('main.dashboardpenjual'))
        elif session['sebagai']=='pembeli':
            return redirect(url_for('main.dashboardpembeli'))
        else:
            return redirect(url_for('main.logout'))
    form=FormLogin()
    if form.validate_on_submit():
        pengguna = Pengguna.query.filter_by(surel=form.email.data).first()
        if pengguna and bcrypt.check_password_hash(pengguna.kunci, form.password.data):
            session['sebagai']=pengguna.sebagai
            session['surel']=pengguna.surel
            session['no']=pengguna.id
            return redirect(url_for('main.admin_index'))
        else:
            flash('Login Gagal. Cek email dan password Anda', 'is-danger')
    return render_template('index.html',form=form)

@main.route("/dashboard")
def dashboard():
    if 'sebagai' in session:
        if session['sebagai']=='admin':
            judul=Judul.query.filter_by(id = 1).first()
            return render_template('dashboard.html', judul=judul)
        return redirect(url_for('main.logout'))
    return redirect(url_for('main.logout'))

@main.route("/dashboardpenjual")
def dashboardpenjual():
    if 'sebagai' in session:
        if session['sebagai']=='penjual':
            judul=Judul.query.filter_by(id = 1).first()
            return render_template('layoutpenjual.html', judul=judul)
        return redirect(url_for('main.logout'))
    return redirect(url_for('main.logout'))

@main.route("/dashboardpembeli")
def dashboardpembeli():
    if 'sebagai' in session:
        if session['sebagai']=='pembeli':
            judul=Judul.query.filter_by(id = 1).first()
            nama=Pengguna.query.filter_by(id = session['no']).first()
            return render_template('layoutpembeli.html', judul=judul,nama=nama)
        return redirect(url_for('main.logout'))
    return redirect(url_for('main.logout'))

@main.route("/logout")
def logout():
    session.pop('sebagai', None)
    session.pop('surel', None)
    session.pop('no', None)
    return redirect(url_for('main.admin_index'))

@main.route("/pembeli/daftar", methods=['GET', 'POST'])
def daftarpembeli():
    if 'sebagai' in session:
        if session['sebagai']=='admin':
            return redirect(url_for('main.dashboard'))
        elif session['sebagai']=='penjual':
            return redirect(url_for('main.dashboardpenjual'))
        elif session['sebagai']=='pembeli':
            return redirect(url_for('main.dashboardpembeli'))
        else:
            return redirect(url_for('main.logout'))
    form = FormRegistrasi()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = Pengguna(nama=form.username.data, surel=form.email.data, kunci=hashed_password,sebagai='pembeli',aktifasi=1)
        dbase.session.add(user)
        dbase.session.commit()
        flash('Akun Pembeli berhasil dibuat! Silahkan Login', 'is-success')
        return redirect(url_for('main.admin_index'))
    return render_template('register.html', title='Signup Pembeli', form=form)

@main.route("/penjual/daftar", methods=['GET', 'POST'])
def daftarpenjual():
    if 'sebagai' in session:
        if session['sebagai']=='admin':
            return redirect(url_for('main.dashboard'))
        elif session['sebagai']=='penjual':
            return redirect(url_for('main.dashboardpenjual'))
        elif session['sebagai']=='pembeli':
            return redirect(url_for('main.dashboardpembeli'))
        else:
            return redirect(url_for('main.logout'))
    form = FormRegistrasi()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = Pengguna(nama=form.username.data, surel=form.email.data, kunci=hashed_password,sebagai='penjual',aktifasi=1)
        dbase.session.add(user)
        dbase.session.commit()
        flash('Akun Penjual berhasil dibuat! Silahkan Login', 'is-success')
        return redirect(url_for('main.admin_index'))
    return render_template('register.html', title='Signup Penjual', form=form)

