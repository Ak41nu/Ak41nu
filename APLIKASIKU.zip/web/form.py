from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, SubmitField, BooleanField, TextAreaField, SelectField
from wtforms.validators import DataRequired, Length, Email, EqualTo, ValidationError
from wtforms.fields import EmailField
from web.database import Pengguna


# Ini Bagian Awal Proses Tabel Pengguna #
class FormUpdateAkun(FlaskForm):
    username = StringField('Username',validators=[DataRequired(), Length(min=2, max=20)])
    email = StringField('Email', render_kw={'disabled':True})
    role = SelectField('Role', validators=[DataRequired()], choices = [])
    biografi = TextAreaField('Biografi')
    picture = FileField('Update Profile Picture', validators=[FileAllowed(['jpg', 'png'])])
    active = BooleanField('Active')
    submit = SubmitField('Update')
    def validate_email(self, email):
        if email.data:
            raise ValidationError('Email tidak dapat diganti')

class FormRegistrasi(FlaskForm):
    username = StringField('Username',validators=[DataRequired(), Length(min=2, max=20)], render_kw={'placeholder': 'Nama', 'autocomplete': 'off'})
    email = StringField('Email',validators=[DataRequired(), Email()], render_kw={'placeholder': 'Email', 'autocomplete': 'off'})
    password = PasswordField('Password', validators=[DataRequired()], render_kw={'placeholder': 'Password', 'autocomplete': 'off'})
    confirm_password = PasswordField('Confirm Password',validators=[DataRequired(), EqualTo('password')], render_kw={'placeholder': 'ConfirmPassword'})
    submit = SubmitField('Sign Up')
    def validate_email(self, email):
        user = Pengguna.query.filter_by(surel=email.data).first()
        if user:
            raise ValidationError('Username sudah ada yang mendaftar. Silahkan pilih yang lain')

class FormLogin(FlaskForm):
    email = StringField('Email',validators=[DataRequired(), Email()], render_kw={'placeholder': 'Email','autocomplete': 'off'})
    password = PasswordField('Password', validators=[DataRequired()], render_kw={'placeholder': 'Password','autocomplete': 'off'})
    submit = SubmitField('Sign In')

class FormPermintaanReset(FlaskForm):
    email = StringField('Email',validators=[DataRequired(), Email()], render_kw={'placeholder': 'Email'})
    submit = SubmitField('Request Password Reset')
    def validate_email(self, email):
        user = Pengguna.query.filter_by(email=email.data).first()
        if user is None:
            raise ValidationError('Email belum pernah didaftarkan. Anda dapat registrasi dengan email tersebut.')

class FormResetPassword(FlaskForm):
    password = PasswordField('Password', validators=[DataRequired()], render_kw={'placeholder': 'Password baru'})
    confirm_password = PasswordField('Confirm Password',validators=[DataRequired(message='Tidak boleh kosong'), EqualTo('password', message='Harus sama dengan field diatas')], render_kw={'placeholder': 'Ulangi password baru'})
    submit = SubmitField('Reset Password')


class FormSebagai(FlaskForm):
    nama = StringField('Nama Role', validators=[DataRequired()])
    submit = SubmitField('Submit')

# Ini bagian akhir tabel pengguna
